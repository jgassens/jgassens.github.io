param(
    [Parameter(Mandatory = $true)]
    [string]$FolderId,

    [Parameter(Mandatory = $true)]
    [string]$FolderPath,

    [string]$DeltaLink,
    [string]$CoverageStart
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

$GraphRequestMaxAttempts = 4
$GraphRequestInitialDelaySeconds = 2

function Test-IsTransientGraphFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]

    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }

    if ($Failure -is [System.Management.Automation.ErrorRecord]) {
        if ($Failure.Exception) {
            $messages.Add([string]$Failure.Exception.Message)
            $exception = $Failure.Exception.InnerException
            while ($exception) {
                $messages.Add([string]$exception.Message)
                $exception = $exception.InnerException
            }
        }
    } elseif ($Failure.Exception) {
        $messages.Add([string]$Failure.Exception.Message)
        $exception = $Failure.Exception.InnerException
        while ($exception) {
            $messages.Add([string]$exception.Message)
            $exception = $exception.InnerException
        }
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    $transientMarkers = @(
        "timed out",
        "timeout",
        "request was aborted",
        "request aborted",
        "transport connection",
        "underlying connection was closed",
        "connection was closed",
        "connection closed",
        "temporarily unavailable",
        "service unavailable",
        "gateway timeout",
        "too many requests",
        "429",
        "502",
        "503",
        "504"
    )

    foreach ($marker in $transientMarkers) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }

    return $false
}

function Invoke-GraphRequestWithRetry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [hashtable]$Headers
    )

    $attempt = 0
    $delaySeconds = $GraphRequestInitialDelaySeconds

    while ($true) {
        try {
            if ($Headers) {
                return Invoke-MgGraphRequest -Method GET -Uri $Uri -Headers $Headers -OutputType PSObject
            }

            return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject
        }
        catch {
            $attempt += 1
            if ($attempt -ge $GraphRequestMaxAttempts -or -not (Test-IsTransientGraphFailure $_)) {
                throw
            }

            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}

function Parse-DateValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    try {
        return [DateTimeOffset]::Parse($Value).ToUniversalTime()
    }
    catch {
        Write-Error "Invalid ISO8601 date value: $Value"
        exit 1
    }
}

function Resolve-InitialDeltaLink {
    param([DateTimeOffset]$CoverageStartDate)

    $coverage = [uri]::EscapeDataString($CoverageStartDate.ToString("o"))
    $select = "id,conversationId,internetMessageId,subject,bodyPreview,body,receivedDateTime,sentDateTime,isRead,hasAttachments,from,sender,toRecipients,ccRecipients,replyTo"
    return "https://graph.microsoft.com/v1.0/me/mailFolders/$([uri]::EscapeDataString($FolderId))/messages/delta?`$select=$select&`$filter=receivedDateTime ge $coverage&`$orderby=receivedDateTime desc&`$top=200"
}

function Resolve-EmailAddress {
    param($Value)

    if ($null -eq $Value -or $null -eq $Value.emailAddress) {
        return [PSCustomObject]@{
            Name = ""
            Address = ""
        }
    }

    return [PSCustomObject]@{
        Name = [string]$Value.emailAddress.name
        Address = [string]$Value.emailAddress.address
    }
}

function Resolve-Participants {
    param($Message)

    $participants = New-Object System.Collections.Generic.List[object]
    $seen = @{}

    function Add-Participant {
        param([string]$Role, $Entry)

        $resolved = Resolve-EmailAddress $Entry
        $key = "$Role|$($resolved.Address)|$($resolved.Name)"
        if ($seen.ContainsKey($key)) {
            return
        }
        $seen[$key] = $true
        $participants.Add([PSCustomObject]@{
            Role = $Role
            DisplayName = $resolved.Name
            Address = $resolved.Address
        })
    }

    if ($Message.from) { Add-Participant -Role "from" -Entry $Message.from }
    if ($Message.sender) { Add-Participant -Role "sender" -Entry $Message.sender }
    foreach ($entry in @($Message.toRecipients)) { Add-Participant -Role "to" -Entry $entry }
    foreach ($entry in @($Message.ccRecipients)) { Add-Participant -Role "cc" -Entry $entry }
    foreach ($entry in @($Message.replyTo)) { Add-Participant -Role "reply_to" -Entry $entry }

    return $participants.ToArray()
}

function Resolve-DateTimeValue {
    param(
        $Value,
        [string]$Fallback = $null
    )

    foreach ($candidate in @($Value, $Fallback)) {
        if ([string]::IsNullOrWhiteSpace([string]$candidate)) {
            continue
        }

        try {
            return ([DateTimeOffset]$candidate).ToUniversalTime().ToString("o")
        }
        catch {
            continue
        }
    }

    return $null
}

function Resolve-BodyText {
    param($Message)

    if ($null -eq $Message.body -or [string]::IsNullOrWhiteSpace([string]$Message.body.content)) {
        return ""
    }

    $bodyText = [string]$Message.body.content
    if ($bodyText.Length -gt 20000) {
        $bodyText = $bodyText.Substring(0, 20000)
    }
    return $bodyText
}

function Normalize-Change {
    param($Message)

    $isRemoved = $Message.PSObject.Properties.Name -contains "@removed"
    if ($isRemoved) {
        return [PSCustomObject]@{
            Id = [string]$Message.id
            ConversationId = [string]$Message.id
            InternetMessageId = $null
            Subject = ""
            BodyPreview = ""
            Body = ""
            ReceivedDateTime = ""
            SentDateTime = ""
            IsRead = $false
            SenderName = ""
            SenderAddress = ""
            FromName = ""
            FromAddress = ""
            HasAttachments = $false
            FolderId = $FolderId
            FolderPath = $FolderPath
            SentByUser = $false
            Participants = @()
            Removed = $true
        }
    }

    $sender = Resolve-EmailAddress $Message.sender
    $from = Resolve-EmailAddress $Message.from
    $participants = Resolve-Participants $Message
    $sentByUser = $FolderPath.ToLowerInvariant().StartsWith("sent items")
    $receivedDateTime = Resolve-DateTimeValue $Message.receivedDateTime
    if (-not $receivedDateTime) {
        return $null
    }

    $sentDateTime = Resolve-DateTimeValue $Message.sentDateTime $Message.receivedDateTime

    return [PSCustomObject]@{
        Id = [string]$Message.id
        ConversationId = [string]$Message.conversationId
        InternetMessageId = [string]$Message.internetMessageId
        Subject = [string]$Message.subject
        BodyPreview = [string]$Message.bodyPreview
        Body = Resolve-BodyText $Message
        ReceivedDateTime = $receivedDateTime
        SentDateTime = if ($sentDateTime) { $sentDateTime } else { $receivedDateTime }
        IsRead = [bool]$Message.isRead
        SenderName = $sender.Name
        SenderAddress = $sender.Address
        FromName = $from.Name
        FromAddress = $from.Address
        HasAttachments = [bool]$Message.hasAttachments
        FolderId = $FolderId
        FolderPath = $FolderPath
        SentByUser = [bool]$sentByUser
        Participants = $participants
        Removed = $false
    }
}

$coverageStartDate = Parse-DateValue $CoverageStart
if ([string]::IsNullOrWhiteSpace($DeltaLink)) {
    if (-not $coverageStartDate) {
        $coverageStartDate = (Get-Date).ToUniversalTime().AddYears(-1)
    }
    $requestUrl = Resolve-InitialDeltaLink $coverageStartDate
} else {
    $requestUrl = $DeltaLink
}

$changes = New-Object System.Collections.Generic.List[object]
$finalDeltaLink = $null

while ($requestUrl) {
    $response = Invoke-GraphRequestWithRetry -Uri $requestUrl -Headers @{ Prefer = 'odata.maxpagesize=200, outlook.body-content-type="text"' }

    if ($response.value) {
        foreach ($message in $response.value) {
            $normalized = Normalize-Change $message
            if ($null -ne $normalized) {
                $changes.Add($normalized)
            }
        }
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
        continue
    }

    $finalDeltaLink = [string]$response.'@odata.deltaLink'
    $requestUrl = $null
}

if (-not $finalDeltaLink) {
    Write-Error "Folder delta sync did not return a deltaLink."
    exit 1
}

if (-not $coverageStartDate) {
    $coverageStartDate = (Get-Date).ToUniversalTime().AddYears(-1)
}

[PSCustomObject]@{
    DeltaLink = $finalDeltaLink
    CoverageStart = $coverageStartDate.ToString("o")
    CoverageEnd = (Get-Date).ToUniversalTime().ToString("o")
    Changes = $changes.ToArray()
} | ConvertTo-Json -Depth 8
