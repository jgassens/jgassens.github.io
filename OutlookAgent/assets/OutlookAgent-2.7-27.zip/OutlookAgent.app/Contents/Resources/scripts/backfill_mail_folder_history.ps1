param(
    [Parameter(Mandatory = $true)]
    [string]$FolderId,

    [Parameter(Mandatory = $true)]
    [string]$FolderPath,

    [Parameter(Mandatory = $true)]
    [string]$Before,

    [Parameter(Mandatory = $true)]
    [string]$TargetCoverageStart,

    [int]$PageSize = 200,
    [int]$MaxPages = 4
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

$GraphRequestMaxAttempts = 4
$GraphRequestInitialDelaySeconds = 2

function Test-IsTransientGraphFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]

    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }

    if ($Failure -is [System.Management.Automation.ErrorRecord]) {
        if ($Failure.Exception) {
            $messages.Add([string]$Failure.Exception.Message)
            $exception = $Failure.Exception.InnerException
            while ($exception) {
                $messages.Add([string]$exception.Message)
                $exception = $exception.InnerException
            }
        }
    } elseif ($Failure.Exception) {
        $messages.Add([string]$Failure.Exception.Message)
        $exception = $Failure.Exception.InnerException
        while ($exception) {
            $messages.Add([string]$exception.Message)
            $exception = $exception.InnerException
        }
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    $transientMarkers = @(
        "timed out",
        "timeout",
        "request was aborted",
        "request aborted",
        "transport connection",
        "underlying connection was closed",
        "connection was closed",
        "connection closed",
        "temporarily unavailable",
        "service unavailable",
        "gateway timeout",
        "too many requests",
        "429",
        "502",
        "503",
        "504"
    )

    foreach ($marker in $transientMarkers) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }

    return $false
}

function Invoke-GraphRequestWithRetry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [hashtable]$Headers
    )

    $attempt = 0
    $delaySeconds = $GraphRequestInitialDelaySeconds

    while ($true) {
        try {
            if ($Headers) {
                return Invoke-MgGraphRequest -Method GET -Uri $Uri -Headers $Headers -OutputType PSObject
            }

            return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject
        }
        catch {
            $attempt += 1
            if ($attempt -ge $GraphRequestMaxAttempts -or -not (Test-IsTransientGraphFailure $_)) {
                throw
            }

            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}

function Parse-DateValue {
    param([string]$Value)

    try {
        return [DateTimeOffset]::Parse($Value).ToUniversalTime()
    }
    catch {
        Write-Error "Invalid ISO8601 date value: $Value"
        exit 1
    }
}

function Resolve-EmailAddress {
    param($Value)

    if ($null -eq $Value -or $null -eq $Value.emailAddress) {
        return [PSCustomObject]@{
            Name = ""
            Address = ""
        }
    }

    return [PSCustomObject]@{
        Name = [string]$Value.emailAddress.name
        Address = [string]$Value.emailAddress.address
    }
}

function Resolve-Participants {
    param($Message)

    $participants = New-Object System.Collections.Generic.List[object]
    $seen = @{}

    function Add-Participant {
        param([string]$Role, $Entry)

        $resolved = Resolve-EmailAddress $Entry
        $key = "$Role|$($resolved.Address)|$($resolved.Name)"
        if ($seen.ContainsKey($key)) {
            return
        }
        $seen[$key] = $true
        $participants.Add([PSCustomObject]@{
            Role = $Role
            DisplayName = $resolved.Name
            Address = $resolved.Address
        })
    }

    if ($Message.from) { Add-Participant -Role "from" -Entry $Message.from }
    if ($Message.sender) { Add-Participant -Role "sender" -Entry $Message.sender }
    foreach ($entry in @($Message.toRecipients)) { Add-Participant -Role "to" -Entry $entry }
    foreach ($entry in @($Message.ccRecipients)) { Add-Participant -Role "cc" -Entry $entry }
    foreach ($entry in @($Message.replyTo)) { Add-Participant -Role "reply_to" -Entry $entry }

    return $participants.ToArray()
}

function Resolve-BodyText {
    param($Message)

    if ($null -eq $Message.body -or [string]::IsNullOrWhiteSpace([string]$Message.body.content)) {
        return ""
    }

    $bodyText = [string]$Message.body.content
    if ($bodyText.Length -gt 20000) {
        $bodyText = $bodyText.Substring(0, 20000)
    }
    return $bodyText
}

function Normalize-Message {
    param($Message)

    $sender = Resolve-EmailAddress $Message.sender
    $from = Resolve-EmailAddress $Message.from
    $participants = Resolve-Participants $Message
    $sentByUser = $FolderPath.ToLowerInvariant().StartsWith("sent items")

    [PSCustomObject]@{
        Id = [string]$Message.id
        ConversationId = [string]$Message.conversationId
        InternetMessageId = [string]$Message.internetMessageId
        Subject = [string]$Message.subject
        BodyPreview = [string]$Message.bodyPreview
        Body = Resolve-BodyText $Message
        ReceivedDateTime = ([DateTimeOffset]$Message.receivedDateTime).ToUniversalTime().ToString("o")
        SentDateTime = ([DateTimeOffset]$Message.sentDateTime).ToUniversalTime().ToString("o")
        IsRead = [bool]$Message.isRead
        SenderName = $sender.Name
        SenderAddress = $sender.Address
        FromName = $from.Name
        FromAddress = $from.Address
        HasAttachments = [bool]$Message.hasAttachments
        FolderId = $FolderId
        FolderPath = $FolderPath
        SentByUser = [bool]$sentByUser
        Participants = $participants
        Removed = $false
    }
}

$beforeDate = Parse-DateValue $Before
$targetDate = Parse-DateValue $TargetCoverageStart
$escapedBefore = [uri]::EscapeDataString($beforeDate.ToString("o"))
$select = "id,conversationId,internetMessageId,subject,bodyPreview,body,receivedDateTime,sentDateTime,isRead,hasAttachments,from,sender,toRecipients,ccRecipients,replyTo"
$requestUrl = "https://graph.microsoft.com/v1.0/me/mailFolders/$([uri]::EscapeDataString($FolderId))/messages?`$select=$select&`$filter=receivedDateTime lt $escapedBefore&`$orderby=receivedDateTime desc&`$top=$PageSize"

$changes = New-Object System.Collections.Generic.List[object]
$oldestFetched = $null
$pagesFetched = 0
$exhaustedHistory = $false
$reachedTarget = $false

while ($requestUrl -and $pagesFetched -lt $MaxPages) {
    $response = Invoke-GraphRequestWithRetry -Uri $requestUrl -Headers @{ Prefer = 'outlook.body-content-type="text"' }
    $pagesFetched += 1

    if (-not $response.value -or $response.value.Count -eq 0) {
        $exhaustedHistory = $true
        break
    }

    foreach ($message in $response.value) {
        $normalized = Normalize-Message $message
        $changes.Add($normalized)

        $messageDate = [DateTimeOffset]::Parse($normalized.ReceivedDateTime).ToUniversalTime()
        if ($null -eq $oldestFetched -or $messageDate -lt $oldestFetched) {
            $oldestFetched = $messageDate
        }

        if ($messageDate -le $targetDate) {
            $reachedTarget = $true
            break
        }
    }

    if ($reachedTarget) {
        break
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
    }
    else {
        $requestUrl = $null
        $exhaustedHistory = $true
    }
}

if ($null -eq $oldestFetched) {
    $coverageStart = $beforeDate
}
else {
    $coverageStart = $oldestFetched
}

[PSCustomObject]@{
    CoverageStart = $coverageStart.ToString("o")
    CoverageEnd = $beforeDate.ToString("o")
    ExhaustedHistory = [bool]$exhaustedHistory
    Changes = $changes.ToArray()
} | ConvertTo-Json -Depth 8
