param([string]$id)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

if (-not $id) {
    Write-Error "Missing -id parameter"
    exit 1
}

$u = $ctx.Account

$result = Get-MgUserMessage -UserId $u `
  -MessageId $id `
  -Property Subject,From,ReceivedDateTime,Body,WebLink `
  -Headers @{"Prefer"="outlook.body-content-type=""text"""}

if (-not $result) {
    Write-Error "Message not found for id: $id"
    exit 1
}

$result |
Select-Object `
  Id,
  Subject,
  @{Name="From";Expression={$_.From.EmailAddress.Address}},
  ReceivedDateTime,
  @{Name="Body";Expression={$_.Body.Content}},
  WebLink |
ConvertTo-Json -Depth 5
