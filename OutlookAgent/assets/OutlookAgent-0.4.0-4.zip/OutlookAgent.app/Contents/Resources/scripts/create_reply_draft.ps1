param(
    [Parameter(Mandatory = $true)][string]$Id,
    [string]$Body = ""
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$encodedSourceId = Encode-GraphPathSegment $Id
$createBody = $null
if ($PSBoundParameters.ContainsKey("Body") -and -not [string]::IsNullOrWhiteSpace($Body)) {
    # Use createReply's comment parameter so Graph/Outlook preserves the
    # standard quoted original-message section below the reply text.
    $createBody = @{
        comment = $Body
    }
}

$created = Invoke-DraftGraphRequest -Method "POST" -Uri "/me/messages/$encodedSourceId/createReply" -Body $createBody
$draft = Get-DraftMessageById -Id $created.id
Assert-IsDraftMessage $draft

ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $draft)
