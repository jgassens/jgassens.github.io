param(
    [Parameter(Mandatory = $true)][string]$Id,
    [Parameter(Mandatory = $true)][string]$To,
    [string]$Comment = ""
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$toRecipients = @(ConvertTo-DraftRecipients $To)
if ($toRecipients.Count -eq 0) {
    throw "DRAFT FORWARD requires at least one To recipient."
}

$encodedSourceId = Encode-GraphPathSegment $Id
$payload = @{
    toRecipients = $toRecipients
}
if (-not [string]::IsNullOrWhiteSpace($Comment)) {
    $payload.comment = $Comment
}

$created = Invoke-DraftGraphRequest -Method "POST" -Uri "/me/messages/$encodedSourceId/createForward" -Body $payload
$draft = Get-DraftMessageById -Id $created.id
Assert-IsDraftMessage $draft
ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $draft)
