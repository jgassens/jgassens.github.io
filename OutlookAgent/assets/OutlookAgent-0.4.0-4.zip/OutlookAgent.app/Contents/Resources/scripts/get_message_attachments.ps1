param(
    [Parameter(Mandatory = $true)]
    [string]$MessageId
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

$GraphRequestMaxAttempts = 4
$GraphRequestInitialDelaySeconds = 2

function Test-IsTransientGraphFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]

    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }

    if ($Failure -is [System.Management.Automation.ErrorRecord]) {
        if ($Failure.Exception) {
            $messages.Add([string]$Failure.Exception.Message)
            $exception = $Failure.Exception.InnerException
            while ($exception) {
                $messages.Add([string]$exception.Message)
                $exception = $exception.InnerException
            }
        }
    } elseif ($Failure.Exception) {
        $messages.Add([string]$Failure.Exception.Message)
        $exception = $Failure.Exception.InnerException
        while ($exception) {
            $messages.Add([string]$exception.Message)
            $exception = $exception.InnerException
        }
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    $transientMarkers = @(
        "timed out",
        "timeout",
        "request was aborted",
        "request aborted",
        "transport connection",
        "underlying connection was closed",
        "connection was closed",
        "connection closed",
        "temporarily unavailable",
        "service unavailable",
        "gateway timeout",
        "too many requests",
        "429",
        "502",
        "503",
        "504"
    )

    foreach ($marker in $transientMarkers) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }

    return $false
}

function Invoke-GraphRequestWithRetry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri
    )

    $attempt = 0
    $delaySeconds = $GraphRequestInitialDelaySeconds

    while ($true) {
        try {
            return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject
        }
        catch {
            $attempt += 1
            if ($attempt -ge $GraphRequestMaxAttempts -or -not (Test-IsTransientGraphFailure $_)) {
                throw
            }

            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}

$requestUrl = "https://graph.microsoft.com/v1.0/me/messages/$([uri]::EscapeDataString($MessageId))/attachments?`$select=id,name,contentType,size,isInline&`$top=200"
$attachments = New-Object System.Collections.Generic.List[object]

while ($requestUrl) {
    $response = Invoke-GraphRequestWithRetry -Uri $requestUrl
    foreach ($attachment in @($response.value)) {
        $attachments.Add([PSCustomObject]@{
            Name = [string]$attachment.name
            ContentType = [string]$attachment.contentType
            Size = [int]$attachment.size
            IsInline = [bool]$attachment.isInline
        })
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
    } else {
        $requestUrl = $null
    }
}

ConvertTo-Json -InputObject @($attachments.ToArray()) -Depth 4
