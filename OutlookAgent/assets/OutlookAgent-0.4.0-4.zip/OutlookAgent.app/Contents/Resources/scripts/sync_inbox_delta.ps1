param(
    [string]$DeltaLink,
    [string]$CoverageStart
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

function Parse-DateValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    try {
        return [DateTimeOffset]::Parse($Value).ToUniversalTime()
    }
    catch {
        Write-Error "Invalid ISO8601 date value: $Value"
        exit 1
    }
}

function Resolve-InitialDeltaLink {
    param([DateTimeOffset]$CoverageStartDate)

    $coverage = [uri]::EscapeDataString($CoverageStartDate.ToString("o"))
    return "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages/delta?`$select=id,subject,from,receivedDateTime,bodyPreview,isRead&`$filter=receivedDateTime ge $coverage&`$orderby=receivedDateTime desc"
}

function Resolve-SenderIdentity {
    param($Message)

    if ($null -eq $Message) {
        return ""
    }

    if ($null -eq $Message.from -or $null -eq $Message.from.emailAddress) {
        return ""
    }

    $name = [string]$Message.from.emailAddress.name
    $address = [string]$Message.from.emailAddress.address

    if (-not [string]::IsNullOrWhiteSpace($name) -and -not [string]::IsNullOrWhiteSpace($address)) {
        return "$name <$address>"
    }
    if (-not [string]::IsNullOrWhiteSpace($name)) {
        return $name
    }
    return $address
}

function Resolve-ReceivedDateTime {
    param($Message)

    if ($null -eq $Message -or [string]::IsNullOrWhiteSpace([string]$Message.receivedDateTime)) {
        return $null
    }

    try {
        return ([DateTimeOffset]$Message.receivedDateTime).ToUniversalTime().ToString("o")
    }
    catch {
        return $null
    }
}

function Normalize-Change {
    param($Message)

    $isRemoved = $Message.PSObject.Properties.Name -contains "@removed"

    if ($isRemoved) {
        return [PSCustomObject]@{
            Id = [string]$Message.id
            Subject = ""
            From = ""
            ReceivedDateTime = ""
            BodyPreview = ""
            IsRead = $false
            InInbox = $false
        }
    }

    $receivedDateTime = Resolve-ReceivedDateTime $Message
    if (-not $receivedDateTime) {
        return $null
    }

        return [PSCustomObject]@{
            Id = [string]$Message.id
            Subject = [string]$Message.subject
            From = (Resolve-SenderIdentity $Message)
            ReceivedDateTime = $receivedDateTime
            BodyPreview = [string]$Message.bodyPreview
            IsRead = [bool]$Message.isRead
        InInbox = $true
    }
}

$coverageStartDate = Parse-DateValue $CoverageStart

if ([string]::IsNullOrWhiteSpace($DeltaLink)) {
    if (-not $coverageStartDate) {
        $coverageStartDate = (Get-Date).ToUniversalTime().AddYears(-1)
    }
    $requestUrl = Resolve-InitialDeltaLink $coverageStartDate
}
else {
    $requestUrl = $DeltaLink
}

$changes = New-Object System.Collections.Generic.List[object]
$finalDeltaLink = $null

while ($requestUrl) {
    $response = Invoke-MgGraphRequest -Method GET -Uri $requestUrl -OutputType PSObject

    if ($response.value) {
        foreach ($message in $response.value) {
            $normalized = Normalize-Change $message
            if ($null -ne $normalized) {
                $changes.Add($normalized)
            }
        }
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
        continue
    }

    $finalDeltaLink = [string]$response.'@odata.deltaLink'
    $requestUrl = $null
}

if (-not $finalDeltaLink) {
    Write-Error "Delta sync did not return a deltaLink."
    exit 1
}

if (-not $coverageStartDate) {
    $coverageStartDate = (Get-Date).ToUniversalTime().AddYears(-1)
}

[PSCustomObject]@{
    DeltaLink = $finalDeltaLink
    CoverageStart = $coverageStartDate.ToString("o")
    CoverageEnd = (Get-Date).ToUniversalTime().ToString("o")
    Changes = $changes.ToArray()
} | ConvertTo-Json -Depth 6
