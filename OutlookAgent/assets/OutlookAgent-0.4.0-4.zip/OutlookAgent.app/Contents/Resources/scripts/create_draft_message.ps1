param(
    [Parameter(Mandatory = $true)][string]$To,
    [string]$Cc = "",
    [string]$Bcc = "",
    [string]$Subject = "",
    [string]$Body = ""
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$toRecipients = @(ConvertTo-DraftRecipients $To)
if ($toRecipients.Count -eq 0) {
    throw "DRAFT NEW requires at least one To recipient."
}

$payload = @{
    subject = $Subject
    body = @{
        contentType = "Text"
        content = $Body
    }
    toRecipients = $toRecipients
}

$ccRecipients = @(ConvertTo-DraftRecipients $Cc)
if ($ccRecipients.Count -gt 0) {
    $payload.ccRecipients = $ccRecipients
}

$bccRecipients = @(ConvertTo-DraftRecipients $Bcc)
if ($bccRecipients.Count -gt 0) {
    $payload.bccRecipients = $bccRecipients
}

$created = Invoke-DraftGraphRequest -Method "POST" -Uri "/me/messages" -Body $payload
$saved = Get-DraftMessageById -Id $created.id
Assert-IsDraftMessage $saved
ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $saved)
