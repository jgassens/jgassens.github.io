param(
    [Parameter(Mandatory = $true)][string]$Id,
    [string]$To = $null,
    [string]$Cc = $null,
    [string]$Bcc = $null,
    [string]$ReplyTo = $null,
    [string]$Subject = $null,
    [string]$Body = $null
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$existing = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $existing

$payload = @{}
if ($PSBoundParameters.ContainsKey("Subject")) {
    $payload.subject = $Subject
}
if ($PSBoundParameters.ContainsKey("Body")) {
    $payload.body = @{
        contentType = "Text"
        content = $Body
    }
}
if ($PSBoundParameters.ContainsKey("To")) {
    $payload.toRecipients = @(ConvertTo-DraftRecipients $To)
}
if ($PSBoundParameters.ContainsKey("Cc")) {
    $payload.ccRecipients = @(ConvertTo-DraftRecipients $Cc)
}
if ($PSBoundParameters.ContainsKey("Bcc")) {
    $payload.bccRecipients = @(ConvertTo-DraftRecipients $Bcc)
}
if ($PSBoundParameters.ContainsKey("ReplyTo")) {
    $payload.replyTo = @(ConvertTo-DraftRecipients $ReplyTo)
}

if ($payload.Count -eq 0) {
    throw "DRAFT UPDATE requires at least one composition field."
}

$encodedId = Encode-GraphPathSegment $Id
$updated = Invoke-DraftGraphRequest -Method "PATCH" -Uri "/me/messages/$encodedId" -Body $payload
if ($null -eq $updated) {
    $updated = Get-DraftMessageById -Id $Id
}
Assert-IsDraftMessage $updated
ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $updated)
