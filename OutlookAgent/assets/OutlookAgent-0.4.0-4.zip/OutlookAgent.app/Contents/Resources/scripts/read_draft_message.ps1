param(
    [Parameter(Mandatory = $true)][string]$Id
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$message = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $message
ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $message)
