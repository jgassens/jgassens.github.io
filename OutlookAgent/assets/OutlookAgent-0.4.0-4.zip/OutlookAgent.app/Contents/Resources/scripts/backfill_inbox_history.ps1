param(
    [Parameter(Mandatory = $true)]
    [string]$Before,

    [Parameter(Mandatory = $true)]
    [string]$TargetCoverageStart,

    [int]$PageSize = 200,
    [int]$MaxPages = 4
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

function Parse-DateValue {
    param([string]$Value)

    try {
        return [DateTimeOffset]::Parse($Value).ToUniversalTime()
    }
    catch {
        Write-Error "Invalid ISO8601 date value: $Value"
        exit 1
    }
}

function Resolve-SenderIdentity {
    param($Message)

    if ($null -eq $Message.from -or $null -eq $Message.from.emailAddress) {
        return ""
    }

    $name = [string]$Message.from.emailAddress.name
    $address = [string]$Message.from.emailAddress.address

    if (-not [string]::IsNullOrWhiteSpace($name) -and -not [string]::IsNullOrWhiteSpace($address)) {
        return "$name <$address>"
    }
    if (-not [string]::IsNullOrWhiteSpace($name)) {
        return $name
    }
    return $address
}

function Normalize-Message {
    param($Message)

    [PSCustomObject]@{
        Id = [string]$Message.id
        Subject = [string]$Message.subject
        From = Resolve-SenderIdentity $Message
        ReceivedDateTime = ([DateTimeOffset]$Message.receivedDateTime).ToUniversalTime().ToString("o")
        BodyPreview = [string]$Message.bodyPreview
        IsRead = [bool]$Message.isRead
        InInbox = $true
    }
}

$beforeDate = Parse-DateValue $Before
$targetDate = Parse-DateValue $TargetCoverageStart
$escapedBefore = [uri]::EscapeDataString($beforeDate.ToString("o"))
$requestUrl = "https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages?`$select=id,subject,from,receivedDateTime,bodyPreview,isRead&`$filter=receivedDateTime lt $escapedBefore&`$orderby=receivedDateTime desc&`$top=$PageSize"

$changes = New-Object System.Collections.Generic.List[object]
$oldestFetched = $null
$pagesFetched = 0
$exhaustedHistory = $false
$reachedTarget = $false

while ($requestUrl -and $pagesFetched -lt $MaxPages) {
    $response = Invoke-MgGraphRequest -Method GET -Uri $requestUrl -OutputType PSObject
    $pagesFetched += 1

    if (-not $response.value -or $response.value.Count -eq 0) {
        $exhaustedHistory = $true
        break
    }

    foreach ($message in $response.value) {
        $normalized = Normalize-Message $message
        $changes.Add($normalized)

        $messageDate = [DateTimeOffset]::Parse($normalized.ReceivedDateTime).ToUniversalTime()
        if ($null -eq $oldestFetched -or $messageDate -lt $oldestFetched) {
            $oldestFetched = $messageDate
        }

        if ($messageDate -le $targetDate) {
            $reachedTarget = $true
            break
        }
    }

    if ($reachedTarget) {
        break
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
    }
    else {
        $requestUrl = $null
        $exhaustedHistory = $true
    }
}

if ($null -eq $oldestFetched) {
    $coverageStart = $beforeDate
}
else {
    $coverageStart = $oldestFetched
}

[PSCustomObject]@{
    CoverageStart = $coverageStart.ToString("o")
    CoverageEnd = $beforeDate.ToString("o")
    ExhaustedHistory = [bool]$exhaustedHistory
    Changes = $changes.ToArray()
} | ConvertTo-Json -Depth 6
