$ErrorActionPreference = "Stop"
$GraphBaseUri = "https://graph.microsoft.com/v1.0"

function Connect-OutlookDraftGraph {
    Connect-MgGraph -Scopes "User.Read","Mail.Read","Mail.ReadWrite" -NoWelcome | Out-Null
}

function ConvertTo-DraftRecipients {
    param([string]$Recipients)

    if ([string]::IsNullOrWhiteSpace($Recipients)) {
        return @()
    }

    $items = @()
    foreach ($raw in ($Recipients -split "[,;]")) {
        $address = $raw.Trim()
        if ($address.Length -eq 0) {
            continue
        }
        $items += @{
            emailAddress = @{
                address = $address
            }
        }
    }
    return @($items)
}

function ConvertFrom-DraftRecipients {
    param($Recipients)

    $items = @()
    if ($null -eq $Recipients) {
        return @()
    }

    foreach ($recipient in @($Recipients)) {
        if ($null -eq $recipient.emailAddress) {
            continue
        }
        $items += @{
            DisplayName = $recipient.emailAddress.name
            Address = $recipient.emailAddress.address
        }
    }
    return @($items)
}

function ConvertTo-DraftMessageShape {
    param($Message)

    @{
        Id = $Message.id
        Subject = $Message.subject
        To = @(ConvertFrom-DraftRecipients $Message.toRecipients)
        Cc = @(ConvertFrom-DraftRecipients $Message.ccRecipients)
        Bcc = @(ConvertFrom-DraftRecipients $Message.bccRecipients)
        BodyPreview = $Message.bodyPreview
        Body = if ($null -ne $Message.body) { $Message.body.content } else { $null }
        LastModifiedDateTime = $Message.lastModifiedDateTime
        IsDraft = [bool]$Message.isDraft
        WebLink = $Message.webLink
    }
}

function ConvertTo-JsonOutput {
    param($Value)

    $Value | ConvertTo-Json -Depth 20 -Compress
}

function Encode-GraphPathSegment {
    param([Parameter(Mandatory = $true)][string]$Value)

    [System.Uri]::EscapeDataString($Value)
}

function Test-DraftGraphRequestAllowed {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Uri
    )

    if ($Method -eq "POST" -and $Uri -eq "/me/messages") {
        return $true
    }
    if ($Method -eq "GET" -and ($Uri -eq "/me/mailFolders/Drafts/messages" -or $Uri.StartsWith("/me/mailFolders/Drafts/messages?"))) {
        return $true
    }
    if ($Method -eq "GET" -and $Uri.StartsWith("/me/messages/") -and $Uri.Contains("?`$select=")) {
        return $true
    }
    if ($Method -eq "PATCH" -and $Uri -match "^/me/messages/[^/]+$") {
        return $true
    }
    if ($Method -eq "POST" -and $Uri -match "^/me/messages/[^/]+/createReply$") {
        return $true
    }
    if ($Method -eq "POST" -and $Uri -match "^/me/messages/[^/]+/createForward$") {
        return $true
    }
    return $false
}

function Invoke-DraftGraphRequest {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("GET","POST","PATCH")]
        [string]$Method,

        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [object]$Body = $null
    )

    if (-not (Test-DraftGraphRequestAllowed -Method $Method -Uri $Uri)) {
        throw "Draft operation attempted an endpoint outside the saved-draft allowlist."
    }

    $resolvedUri = Resolve-DraftGraphUri -Uri $Uri
    $params = @{
        Method = $Method
        Uri = $resolvedUri
        OutputType = "PSObject"
    }
    if ($null -ne $Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 20)
        $params.ContentType = "application/json"
    }

    Invoke-MgGraphRequest @params
}

function Resolve-DraftGraphUri {
    param([Parameter(Mandatory = $true)][string]$Uri)

    if ($Uri.StartsWith("https://graph.microsoft.com/v1.0/")) {
        return $Uri
    }
    if ($Uri.StartsWith("/")) {
        return "$GraphBaseUri$Uri"
    }
    throw "Draft operation attempted a malformed Graph URI."
}

function Get-DraftMessageById {
    param([Parameter(Mandatory = $true)][string]$Id)

    $encodedId = Encode-GraphPathSegment $Id
    $select = "id,subject,toRecipients,ccRecipients,bccRecipients,bodyPreview,body,lastModifiedDateTime,isDraft,webLink"
    Invoke-DraftGraphRequest -Method "GET" -Uri "/me/messages/$encodedId`?`$select=$select"
}

function Assert-IsDraftMessage {
    param($Message)

    if ($null -eq $Message -or $Message.isDraft -ne $true) {
        throw "Target message is not an Outlook saved draft."
    }
}
