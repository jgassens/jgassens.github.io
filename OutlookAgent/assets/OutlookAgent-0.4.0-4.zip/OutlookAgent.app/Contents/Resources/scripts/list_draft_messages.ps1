param(
    [int]$Limit = 20
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$safeLimit = [Math]::Max(1, [Math]::Min($Limit, 50))
$select = "id,subject,toRecipients,ccRecipients,bccRecipients,bodyPreview,lastModifiedDateTime,isDraft,webLink"
$uri = "/me/mailFolders/Drafts/messages?`$top=$safeLimit&`$orderby=lastModifiedDateTime%20desc&`$select=$select"
$response = Invoke-DraftGraphRequest -Method "GET" -Uri $uri

$drafts = @()
foreach ($message in @($response.value)) {
    if ($message.isDraft -eq $true) {
        $drafts += ConvertTo-DraftMessageShape $message
    }
    if ($drafts.Count -ge $safeLimit) {
        break
    }
}

ConvertTo-JsonOutput @{
    Drafts = @($drafts)
}
