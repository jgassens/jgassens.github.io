param(
    [int]$Top = 20,
    [string]$Sender,
    [string]$Keywords,
    [switch]$UnreadOnly,
    [string]$ReceivedAfter,
    [string]$ReceivedBefore
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

if ($Top -le 0) {
    Write-Error "Top must be greater than zero."
    exit 1
}

$u = $ctx.Account

function Parse-DateValue {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return $null
    }

    try {
        return [DateTimeOffset]::Parse($Value)
    }
    catch {
        Write-Error "Invalid ISO8601 date value: $Value"
        exit 1
    }
}

function Normalize-Text {
    param([string]$Value)

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return ""
    }

    return ($Value.ToLowerInvariant() -replace "\s+", " ").Trim()
}

function Resolve-SenderAddress {
    param($Message)

    if ($null -eq $Message.From -or $null -eq $Message.From.EmailAddress) {
        return ""
    }

    return [string]$Message.From.EmailAddress.Address
}

$receivedAfterDate = Parse-DateValue $ReceivedAfter
$receivedBeforeDate = Parse-DateValue $ReceivedBefore
$normalizedSender = Normalize-Text $Sender
$normalizedKeywords = Normalize-Text $Keywords
$keywordTokens = @()
if ($normalizedKeywords) {
    $keywordTokens = $normalizedKeywords.Split(" ", [System.StringSplitOptions]::RemoveEmptyEntries)
}

try {
    $inbox = Get-MgUserMailFolder -UserId $u `
      -MailFolderId "inbox" `
      -Property Id,DisplayName
}
catch {
    $inbox = Get-MgUserMailFolder -UserId $u `
      -Top 100 `
      -Property Id,DisplayName |
    Where-Object { $_.DisplayName -eq "Inbox" } |
    Select-Object -First 1
}

if (-not $inbox) {
    Write-Error "Inbox folder could not be resolved."
    exit 1
}

$fetchTop = [Math]::Max([Math]::Min($Top * 10, 500), 200)

$messages = Get-MgUserMailFolderMessage -UserId $u `
  -MailFolderId $inbox.Id `
  -Top $fetchTop `
  -Property Id,Subject,From,ReceivedDateTime,BodyPreview,IsRead |
Sort-Object ReceivedDateTime -Descending

$results = foreach ($message in $messages) {
    $senderAddress = Resolve-SenderAddress $message
    $normalizedSenderAddress = Normalize-Text $senderAddress
    $subject = [string]$message.Subject
    $preview = [string]$message.BodyPreview
    $normalizedSubject = Normalize-Text $subject
    $normalizedPreview = Normalize-Text $preview
    $received = [DateTimeOffset]$message.ReceivedDateTime

    if ($UnreadOnly -and $message.IsRead) {
        continue
    }

    if ($receivedAfterDate -and $received -lt $receivedAfterDate) {
        continue
    }

    if ($receivedBeforeDate -and $received -ge $receivedBeforeDate) {
        continue
    }

    $score = 0
    $matchReason = $null

    if ($normalizedSender) {
        if ($normalizedSenderAddress -eq $normalizedSender) {
            $score += 100
        }
        elseif ($normalizedSenderAddress.Contains($normalizedSender)) {
            $score += 80
        }
        else {
            continue
        }

        if ($receivedAfterDate -and $receivedBeforeDate) {
            $matchReason = "sender matched, this month"
        }
        else {
            $matchReason = "sender matched"
        }
    }

    if ($keywordTokens.Count -gt 0) {
        $subjectHits = 0
        $previewHits = 0

        if ($normalizedKeywords -and $normalizedSubject.Contains($normalizedKeywords)) {
            $subjectHits += 2
            $score += 60
        }
        elseif ($normalizedKeywords -and $normalizedPreview.Contains($normalizedKeywords)) {
            $previewHits += 2
            $score += 45
        }

        foreach ($token in $keywordTokens) {
            if ($normalizedSubject.Contains($token)) {
                $subjectHits += 1
                $score += 15
            }
            elseif ($normalizedPreview.Contains($token)) {
                $previewHits += 1
                $score += 8
            }
        }

        if ($subjectHits -eq 0 -and $previewHits -eq 0) {
            continue
        }

        if (-not $matchReason) {
            if ($subjectHits -gt 0) {
                $matchReason = "subject matched: $Keywords"
            }
            else {
                $matchReason = "preview matched: $Keywords"
            }
        }

        if (-not $message.IsRead) {
            $score += 3
        }
    }

    if ($UnreadOnly -and -not $matchReason) {
        $matchReason = "unread"
        $score += 50
    }

    if (-not $matchReason) {
        $matchReason = "matched filters"
    }

    [PSCustomObject]@{
        Score = $score
        ReceivedSort = $received
        Id = $message.Id
        Subject = $subject
        From = $senderAddress
        ReceivedDateTime = $message.ReceivedDateTime
        BodyPreview = $preview
        IsRead = [bool]$message.IsRead
        MatchReason = $matchReason
    }
}

$results = @(
    $results |
    Sort-Object Score, ReceivedSort -Descending |
    Select-Object -First $Top |
    Select-Object Id, Subject, From, ReceivedDateTime, BodyPreview, IsRead, MatchReason
)

if ($results.Count -eq 0) {
    "[]"
    exit 0
}

$results | ConvertTo-Json -Depth 5
