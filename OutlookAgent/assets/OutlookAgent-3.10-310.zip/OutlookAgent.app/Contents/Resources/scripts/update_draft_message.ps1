param(
    [Parameter(Mandatory = $true)][string]$Id,
    [string]$To = $null,
    [string]$Cc = $null,
    [string]$Bcc = $null,
    [string]$ReplyTo = $null,
    [string]$Subject = $null,
    [string]$Body = $null
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$existing = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $existing

$payload = @{}
if ($PSBoundParameters.ContainsKey("Subject")) {
    $payload.subject = $Subject
}
if ($PSBoundParameters.ContainsKey("Body")) {
    $payload.body = @{
        contentType = "Text"
        content = $Body
    }
}
# Recipient edits are additive: each field keeps everyone already on it and
# gains the addresses given. Graph's PATCH replaces a whole collection, so the
# full merged lists are sent together. An address lands once, at its highest
# field (To over Cc over Bcc). Nothing here can drop an addressee on purpose —
# that keeps a reply's Outlook-derived recipients intact whatever is added.
$editsRecipients = $PSBoundParameters.ContainsKey("To") -or $PSBoundParameters.ContainsKey("Cc") -or $PSBoundParameters.ContainsKey("Bcc")
if ($editsRecipients) {
    $payload.toRecipients = @(Merge-DraftRecipients -Existing $existing.toRecipients -Added $To)
    $toKeys = @(Get-DraftRecipientAddressKeys $payload.toRecipients)
    $payload.ccRecipients = @(Merge-DraftRecipients -Existing $existing.ccRecipients -Added $Cc -Skip $toKeys)
    $ccKeys = @(Get-DraftRecipientAddressKeys $payload.ccRecipients)
    $payload.bccRecipients = @(Merge-DraftRecipients -Existing $existing.bccRecipients -Added $Bcc -Skip ($toKeys + $ccKeys))
}
if ($PSBoundParameters.ContainsKey("ReplyTo")) {
    $payload.replyTo = @(ConvertTo-DraftRecipients $ReplyTo)
}

if ($payload.Count -eq 0) {
    throw "DRAFT UPDATE requires at least one composition field."
}

$encodedId = Encode-GraphPathSegment $Id
$updated = Invoke-DraftGraphRequest -Method "PATCH" -Uri "/me/messages/$encodedId" -Body $payload
if ($null -eq $updated) {
    $updated = Get-DraftMessageById -Id $Id
}
Assert-IsDraftMessage $updated
ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $updated)
