# This is the only interactive Graph login. Only the GUI Sign in button runs it.
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

try {
    Connect-MgGraph -TenantId utdallas.edu -Scopes "User.Read","Mail.Read","Mail.ReadWrite" -NoWelcome -ErrorAction Stop | Out-Null
    $ctx = Get-MgContext
    if (-not $ctx -or -not $ctx.Account) { throw "Microsoft sign-in did not return an account." }
    Write-Output "Signed in to Microsoft as $($ctx.Account)."
}
catch {
    [Console]::Error.WriteLine("Microsoft sign-in failed: $($_.Exception.Message)")
    exit 1
}
