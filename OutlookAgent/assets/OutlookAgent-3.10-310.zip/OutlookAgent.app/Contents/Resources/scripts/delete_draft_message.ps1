param(
    [Parameter(Mandatory = $true)][string]$Id
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

# The isDraft assert is the whole fence. DELETE is irreversible and the endpoint
# shape is the same one that would delete real mail, so the target is fetched and
# proved to be an unsent draft before the verb is ever issued. A message that has
# been sent, or that has moved out of Drafts, fails here.
$existing = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $existing

$shape = ConvertTo-DraftMessageShape $existing

$encodedId = Encode-GraphPathSegment $Id
Invoke-DraftGraphRequest -Method "DELETE" -Uri "/me/messages/$encodedId" | Out-Null

# Report what was removed, from the copy taken before the delete: afterwards
# there is nothing left to describe, and "deleted something" is not an answer.
ConvertTo-JsonOutput @{
    Deleted = $true
    Draft = $shape
}
