param([string]$id)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

. (Join-Path $PSScriptRoot "graph_auth_helpers.ps1")
$ctx = Connect-OutlookGraphSilent -Scopes "User.Read","Mail.Read"

if (-not $id) {
    Write-Error "Missing -id parameter"
    exit 1
}

$u = $ctx.Account

$result = Get-MgUserMessage -UserId $u `
  -MessageId $id `
  -Property Subject,From,ReceivedDateTime,Body,WebLink `
  -Headers @{"Prefer"="outlook.body-content-type=""text"""}

if (-not $result) {
    Write-Error "Message not found for id: $id"
    exit 1
}

$result |
Select-Object `
  Id,
  Subject,
  @{Name="From";Expression={$_.From.EmailAddress.Address}},
  ReceivedDateTime,
  @{Name="Body";Expression={$_.Body.Content}},
  WebLink |
ConvertTo-Json -Depth 5
