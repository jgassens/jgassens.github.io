param([int]$Top = 10)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

. (Join-Path $PSScriptRoot "graph_auth_helpers.ps1")
$ctx = Connect-OutlookGraphSilent -Scopes "User.Read","Mail.Read"

$u = $ctx.Account

if ($Top -le 0) {
    Write-Error "Top must be greater than zero."
    exit 1
}

try {
    $inbox = Get-MgUserMailFolder -UserId $u `
      -MailFolderId "inbox" `
      -Property Id,DisplayName
}
catch {
    $inbox = Get-MgUserMailFolder -UserId $u `
      -Top 100 `
      -Property Id,DisplayName |
    Where-Object { $_.DisplayName -eq "Inbox" } |
    Select-Object -First 1
}

if (-not $inbox) {
    Write-Error "Inbox folder could not be resolved."
    exit 1
}

Get-MgUserMailFolderMessage -UserId $u `
  -MailFolderId $inbox.Id `
  -Top $Top `
  -Property Id,Subject,From,ReceivedDateTime,BodyPreview,IsRead |
Sort-Object ReceivedDateTime -Descending |
Select-Object `
  Id,
  Subject,
  @{Name="From";Expression={$_.From.EmailAddress.Address}},
  ReceivedDateTime,
  BodyPreview,
  IsRead |
ConvertTo-Json -Depth 5
