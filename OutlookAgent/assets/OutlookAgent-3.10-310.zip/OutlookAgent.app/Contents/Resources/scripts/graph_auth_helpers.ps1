$ErrorActionPreference = "Stop"

function Format-OutlookGraphDiagnostic {
    param([string]$Text)
    # Redact BEFORE truncating: a truncated token must never become loggable.
    $line = $Text -replace 'eyJ[A-Za-z0-9_\-]{8,}(\.[A-Za-z0-9_\-]+)*', '[redacted]'
    $line = $line -replace '[A-Za-z0-9_+/=\-]{40,}', '[redacted]'
    $line = ($line -replace '[\r\n\u0085\u2028\u2029]+', ' ').Trim()
    if ($line.Length -gt 200) { $line = $line.Substring(0, 200) }
    return $line
}

function Stop-OutlookSignInRequired {
    param([string]$Reason)
    $reasonLine = Format-OutlookGraphDiagnostic -Text $Reason
    [Console]::Error.WriteLine("OUTLOOKAGENT_SIGNIN_REQUIRED: $reasonLine")
    exit 3
}

function Stop-OutlookGraphHelperBroken {
    param([string]$Reason, [System.Exception]$Exception)
    if ($Exception) { Stop-OutlookGraphFailure -Exception $Exception -HelperBrokenReason $Reason }
    $reasonLine = Format-OutlookGraphDiagnostic -Text $Reason
    [Console]::Error.WriteLine("OUTLOOKAGENT_GRAPH_HELPER_BROKEN: $reasonLine")
    exit 4
}

function Stop-OutlookGraphFailure {
    param([System.Exception]$Exception, [string]$HelperBrokenReason)
    # Match names, not type literals: assemblies can be absent on import failure.
    $authRequiredTypes = @(
        'Azure.Identity.AuthenticationRequiredException',
        'Azure.Identity.CredentialUnavailableException',
        'Microsoft.Identity.Client.MsalUiRequiredException'
    )
    $pending = [Collections.Generic.Stack[System.Exception]]::new()
    $seen = [Collections.Generic.HashSet[System.Exception]]::new()
    $names = [Collections.Generic.List[string]]::new()
    $requiresSignIn = $false
    $helperBroken = -not [string]::IsNullOrEmpty($HelperBrokenReason)
    $innermost = $Exception
    $pending.Push($Exception)
    while ($pending.Count -gt 0) {
        $current = $pending.Pop()
        if (-not $seen.Add($current)) { continue }
        $typeName = $current.GetType().FullName
        $names.Add($typeName)
        if ($authRequiredTypes -contains $typeName) { $requiresSignIn = $true }
        if (@(
            'System.TypeLoadException', 'System.Reflection.ReflectionTypeLoadException',
            'System.IO.FileLoadException',
            'System.MissingMethodException', 'System.MissingMemberException',
            'System.Reflection.AmbiguousMatchException', 'System.InvalidCastException',
            'System.Reflection.TargetParameterCountException'
        ) -contains $typeName) { $helperBroken = $true }
        if ($typeName -eq 'System.IO.FileNotFoundException' -and $current.FileName -match '(\.dll$|, Version=)') { $helperBroken = $true }
        if (-not $current.InnerException) { $innermost = $current }
        if ($current.InnerException) { $pending.Push($current.InnerException) }
        $baseException = $current.GetBaseException()
        if ($baseException -and $baseException -ne $current) { $pending.Push($baseException) }
        if ($typeName -eq 'System.AggregateException') {
            foreach ($inner in $current.InnerExceptions) { $pending.Push($inner) }
        }
    }
    # Wrapped Invoke/task failures keep their type chain and a bounded, redacted
    # leaf message. For aggregates, the last visited leaf supplies the message.
    $message = Format-OutlookGraphDiagnostic -Text $innermost.Message
    $reasonLine = $names -join ' -> '
    if ($message) { $reasonLine += ": $message" }
    if ($helperBroken) {
        $prefix = Format-OutlookGraphDiagnostic -Text $HelperBrokenReason
        if ($prefix) { $reasonLine = "$prefix; $reasonLine" }
        [Console]::Error.WriteLine("OUTLOOKAGENT_GRAPH_HELPER_BROKEN: $reasonLine")
        exit 4
    }
    if ($requiresSignIn) {
        [Console]::Error.WriteLine("OUTLOOKAGENT_SIGNIN_REQUIRED: $reasonLine")
        exit 3
    }
    [Console]::Error.WriteLine("OUTLOOKAGENT_GRAPH_TRANSIENT: $reasonLine")
    exit 1
}

function Resolve-OutlookGraphType {
    param([string]$AssemblyName, [string]$FullName, [System.Runtime.Loader.AssemblyLoadContext]$Context)
    $matches = @(
        foreach ($loadContext in [System.Runtime.Loader.AssemblyLoadContext]::All) {
            if ($Context -and -not [object]::ReferenceEquals($Context, $loadContext)) { continue }
            foreach ($assembly in $loadContext.Assemblies) {
                if ($assembly.GetName().Name -eq $AssemblyName) { $assembly }
            }
        }
    )
    if ($matches.Count -ne 1) {
        Stop-OutlookGraphHelperBroken -Reason "Expected one loaded $AssemblyName assembly in the required context; found $($matches.Count)."
    }
    return $matches[0].GetType($FullName, $true)
}

function Get-OutlookGraphProperty {
    param([Type]$Type, [string]$Name, [switch]$Writable)
    $property = $Type.GetProperty($Name, [Reflection.BindingFlags]'Public,Instance')
    if (-not $property -or -not $property.CanRead -or ($Writable -and -not $property.CanWrite)) {
        Stop-OutlookGraphHelperBroken -Reason "Missing required property $($Type.FullName).$Name."
    }
    return $property
}

function Get-OutlookGraphTaskMethods {
    param([Type]$TaskType)
    if (-not [Threading.Tasks.Task].IsAssignableFrom($TaskType)) {
        Stop-OutlookGraphHelperBroken -Reason "The Graph auth-record API must return a Task."
    }
    $getAwaiter = $TaskType.GetMethod('GetAwaiter', [Type[]]@())
    if (-not $getAwaiter) { Stop-OutlookGraphHelperBroken -Reason "Missing Task.GetAwaiter API." }
    $getResult = $getAwaiter.ReturnType.GetMethod('GetResult', [Type[]]@())
    if (-not $getResult) { Stop-OutlookGraphHelperBroken -Reason "Missing Task awaiter GetResult API." }
    return [pscustomobject]@{ GetAwaiter = $getAwaiter; GetResult = $getResult }
}

# Browser-suppression evidence: Microsoft.Graph.Authentication 2.36.1 ships
# Dependencies/Azure.Identity.dll. InteractiveBrowserCredential.GetTokenImplAsync
# (<GetTokenImplAsync>d__56.MoveNext, IL 0x0154-0x0258) calls AcquireTokenSilentAsync,
# then checks DisableAutomaticAuthentication and throws BEFORE the only call to
# GetTokenViaBrowserLoginAsync (0x026c). Never call Authenticate on this credential.
# Microsoft.Graph.Authentication.Core.dll's AuthenticationHelpers uses the auth
# record from ReadAuthRecordAsync and the persistent cache name "mg.msal.cache"
# (GetTokenCachePersistenceOptions). Reuse those, but NOT its interactive helper.
# Static PE/IL evidence (no Graph import/execution during investigation):
# ModuleInitializer..cctor IL_0068 names "msgraph-load-context". Its
# AssemblyLoadContextProxy reflects the plain AssemblyLoadContext(string,bool)
# constructor (NOT a subclass); ResolvingHandler IL_0037-0042 loads bundled
# dependencies through that context, preferring Dependencies/Core on PS Core.
# The manifest imports Authentication/Core as binary modules: installed PS 7.6
# ExecutionContext.LoadAssembly IL_000e uses Assembly.LoadFrom (default context).
# ClrFacade.GetPSVisibleAssemblies.MoveNext IL_0028 enumerates Default, not All
# (apart from generated PS assemblies). An isolated dependency is invisible:
# a self-built isolated ALC fixture reproduces the bare RuntimeException "Unable
# to find type", while reflected task/property/constructor/GetToken calls work.
# This verifies the mechanism; the live exception site/context inventory remains
# inferred because Graph was never imported in this investigation.
# ReadAuthRecordAsync's return type is
# Task<Azure.Identity.AuthenticationRecord>; use that signature to load/anchor
# Identity, and credential.BaseType to materialize Core, before enumerating ALCs.
# Record/options/cache/credential/request/token types MUST use that same context;
# the module's helper itself can live in PowerShell's ordinary context.
# Static signatures also show GetToken(TokenRequestContext,CancellationToken),
# public string Username/ClientId/TenantId, and TokenRequestContext(string[],string)
# plus a nine-parameter overload with eight optional parameters. Explicit two-arg
# construction avoids PS optional-overload binding; nest string[] in object[] so
# reflection receives ONE scopes argument. Task awaiters are reflected explicitly.
# Missing assemblies/types/members are helper bugs (exit 4), never sign-in fixes.
# Connect-MgGraph below uses ONLY AccessToken:
# the Core DLL's UserProvidedTokenCredential returns that token, with no UI fallback.
function Connect-OutlookGraphSilent {
    param([string[]]$Scopes = @("User.Read","Mail.Read"))

    $resolvingAPI = $true
    try {
        Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
        $helperType = Resolve-OutlookGraphType -AssemblyName 'Microsoft.Graph.Authentication.Core' -FullName 'Microsoft.Graph.PowerShell.Authentication.Core.Utilities.AuthenticationHelpers'
        $staticFlags = [Reflection.BindingFlags]'Public,NonPublic,Static'
        $readRecord = $helperType.GetMethod('ReadAuthRecordAsync', $staticFlags, $null, [Type[]]@(), $null)
        if (-not $readRecord) { Stop-OutlookGraphHelperBroken -Reason "Missing required ReadAuthRecordAsync API." }
        $recordTypes = $readRecord.ReturnType.GetGenericArguments()
        if ($recordTypes.Count -ne 1 -or $recordTypes[0].FullName -ne 'Azure.Identity.AuthenticationRecord') {
            Stop-OutlookGraphHelperBroken -Reason "Unexpected ReadAuthRecordAsync return type."
        }
        $context = [System.Runtime.Loader.AssemblyLoadContext]::GetLoadContext($recordTypes[0].Assembly)
        $recordType = Resolve-OutlookGraphType -AssemblyName 'Azure.Identity' -FullName 'Azure.Identity.AuthenticationRecord' -Context $context
        if ($recordType -ne $recordTypes[0]) { Stop-OutlookGraphHelperBroken -Reason "Auth-record load context mismatch." }
        $optionsType = Resolve-OutlookGraphType -AssemblyName 'Azure.Identity' -FullName 'Azure.Identity.InteractiveBrowserCredentialOptions' -Context $context
        $cacheType = Resolve-OutlookGraphType -AssemblyName 'Azure.Identity' -FullName 'Azure.Identity.TokenCachePersistenceOptions' -Context $context
        $credentialType = Resolve-OutlookGraphType -AssemblyName 'Azure.Identity' -FullName 'Azure.Identity.InteractiveBrowserCredential' -Context $context
        # Materialize Azure.Core via the credential's declared base type. Do not
        # load DLLs by path or select another module's default-context Azure.Core.
        $null = $credentialType.BaseType
        $requestType = Resolve-OutlookGraphType -AssemblyName 'Azure.Core' -FullName 'Azure.Core.TokenRequestContext' -Context $context
        $tokenType = Resolve-OutlookGraphType -AssemblyName 'Azure.Core' -FullName 'Azure.Core.AccessToken' -Context $context
        $getToken = $credentialType.GetMethod('GetToken', [Type[]]@($requestType, [Threading.CancellationToken]))
        if (-not $getToken -or $getToken.ReturnType -ne $tokenType) { Stop-OutlookGraphHelperBroken -Reason "Missing compatible GetToken API." }
        $requestConstructor = $requestType.GetConstructor([Type[]]@([string[]], [string]))
        if (-not $requestConstructor -or -not $optionsType.GetConstructor([Type[]]@()) -or
            -not $cacheType.GetConstructor([Type[]]@()) -or -not $credentialType.GetConstructor([Type[]]@($optionsType))) {
            Stop-OutlookGraphHelperBroken -Reason "Missing required credential/options/request constructor."
        }
        $writeRecord = $helperType.GetMethod('WriteAuthRecordAsync', $staticFlags, $null, [Type[]]@($recordType), $null)
        if (-not $writeRecord) { Stop-OutlookGraphHelperBroken -Reason "Missing compatible WriteAuthRecordAsync API." }
        $readTaskMethods = Get-OutlookGraphTaskMethods -TaskType $readRecord.ReturnType
        $writeTaskMethods = Get-OutlookGraphTaskMethods -TaskType $writeRecord.ReturnType
        $usernameProperty = Get-OutlookGraphProperty -Type $recordType -Name 'Username'
        $clientIDProperty = Get-OutlookGraphProperty -Type $recordType -Name 'ClientId'
        $tenantIDProperty = Get-OutlookGraphProperty -Type $recordType -Name 'TenantId'
        $optionProperties = @{}
        foreach ($name in @('DisableAutomaticAuthentication', 'AuthenticationRecord', 'ClientId', 'TenantId', 'AuthorityHost', 'TokenCachePersistenceOptions')) {
            $optionProperties[$name] = Get-OutlookGraphProperty -Type $optionsType -Name $name -Writable
        }
        if ($optionProperties['AuthenticationRecord'].PropertyType -ne $recordType -or
            $optionProperties['TokenCachePersistenceOptions'].PropertyType -ne $cacheType) {
            Stop-OutlookGraphHelperBroken -Reason "Credential options load context mismatch."
        }
        $cacheNameProperty = Get-OutlookGraphProperty -Type $cacheType -Name 'Name' -Writable
        $tokenProperty = Get-OutlookGraphProperty -Type $tokenType -Name 'Token'
        $resolvingAPI = $false

        $recordTask = $readRecord.Invoke($null, @())
        if (-not $recordTask -or -not $readRecord.ReturnType.IsInstanceOfType($recordTask)) {
            Stop-OutlookGraphHelperBroken -Reason "ReadAuthRecordAsync did not return the declared Task."
        }
        $recordAwaiter = $readTaskMethods.GetAwaiter.Invoke($recordTask, @())
        $record = $readTaskMethods.GetResult.Invoke($recordAwaiter, @())
        if (-not $record) { Stop-OutlookSignInRequired -Reason "No saved Microsoft sign-in is available." }
        if ($record.GetType() -ne $recordType) { Stop-OutlookGraphHelperBroken -Reason "Returned auth-record load context mismatch." }
        $username = $usernameProperty.GetValue($record)
        if (-not $username) { Stop-OutlookSignInRequired -Reason "No saved Microsoft sign-in is available." }

        $options = [Activator]::CreateInstance($optionsType)
        $optionProperties['DisableAutomaticAuthentication'].SetValue($options, $true)
        $optionProperties['AuthenticationRecord'].SetValue($options, $record)
        $optionProperties['ClientId'].SetValue($options, $clientIDProperty.GetValue($record))
        $optionProperties['TenantId'].SetValue($options, $tenantIDProperty.GetValue($record))
        $optionProperties['AuthorityHost'].SetValue($options, [Uri]"https://login.microsoftonline.com")
        $cacheOptions = [Activator]::CreateInstance($cacheType)
        $cacheNameProperty.SetValue($cacheOptions, 'mg.msal.cache')
        $optionProperties['TokenCachePersistenceOptions'].SetValue($options, $cacheOptions)
        $credential = [Activator]::CreateInstance($credentialType, [object[]]@($options))
        $requestArguments = [object[]]::new(2)
        $requestArguments[0] = [string[]]$Scopes
        $requestArguments[1] = $null
        $request = $requestConstructor.Invoke($requestArguments)
        $deadline = [Threading.CancellationTokenSource]::new([TimeSpan]::FromSeconds(30))
        try {
            $token = $getToken.Invoke($credential, [object[]]@($request, $deadline.Token))
            $secureToken = ConvertTo-SecureString -String $tokenProperty.GetValue($token) -AsPlainText -Force
            try {
                Connect-MgGraph -AccessToken $secureToken -NoWelcome -ErrorAction Stop | Out-Null
            }
            catch {
                $connectException = $_.Exception
                # Connect's catch logs out and deletes the record even for a
                # transient failure. Restore the already-read record through
                # Graph's own serializer; never hand-write JSON or log tokens.
                try {
                    $writeTask = $writeRecord.Invoke($null, @($record))
                    $writeAwaiter = $writeTaskMethods.GetAwaiter.Invoke($writeTask, @())
                    $writeTaskMethods.GetResult.Invoke($writeAwaiter, @()) | Out-Null
                }
                catch {
                    # Preserve the original failure's classification even if
                    # restoring the record also fails (e.g. disk unavailable).
                }
                throw $connectException
            }
        }
        finally { $deadline.Dispose() }
        return [pscustomobject]@{ Account = $username }
    }
    catch {
        if ($resolvingAPI) { Stop-OutlookGraphHelperBroken -Reason "Cannot bind the Graph silent-auth API" -Exception $_.Exception }
        Stop-OutlookGraphFailure -Exception $_.Exception
    }
}
