param(
    [Parameter(Mandatory = $true)][string]$Id,
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][string]$ContentType,
    [Parameter(Mandatory = $true)][string]$PayloadPath,

    # Graph caps a single-request attachment POST near 4 MB and base64 inflates
    # the body by 4/3, so anything past this goes through an upload session.
    [long]$InlineMaxBytes = 3000000,

    # Chunk size must be a multiple of 320 KiB (327680) and stay under 4 MB.
    [long]$ChunkBytes = 3276800
)

# Adds one file attachment to an existing Outlook draft, choosing between the
# single-request POST and a chunked upload session by size.
#
# The file arrives already staged at $PayloadPath by the Swift caller. This
# script performs zero filesystem writes and never opens a path the user chose:
# DraftAttachmentService owns the source-path policy and copies the approved
# file into a private temp directory it created itself. Keeping the read here to
# that one staging path leaves the policy in testable Swift, the same split
# scripts/download_attachment.ps1 uses in the other direction.
#
# The size branch lives here rather than in Swift because the threshold is a
# Graph constraint, and this is the only layer that knows about Graph.

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

# The fence: attachment bytes only ever land on a message that is still a draft.
$existing = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $existing

# One probe, not Test-Path followed by Get-Item. The Swift caller removes the
# staging directory as soon as its call unwinds, so a cancelled attach can pull
# the file out from under a two-step check and produce a baffling "could not
# find item /var/folders/..." instead of something a human can act on.
$staged = $null
try {
    $staged = Get-Item -LiteralPath $PayloadPath -ErrorAction Stop
}
catch {
    throw "Draft attachment staging file is no longer available. The attach was most likely cancelled while it was still running."
}

$totalSize = [long]$staged.Length
if ($totalSize -le 0) {
    throw "Draft attachment staging file was empty."
}

$encodedId = Encode-GraphPathSegment $Id

# An upload session reports no usable identity for what it produced, so the
# attachment is identified by diffing the draft's attachment ids around the
# write. Doing it for both paths keeps one answer shape.
$idsBefore = @{}
foreach ($attachment in @(Get-DraftAttachments -Id $Id)) {
    $idsBefore[[string]$attachment.Id] = $true
}

if ($totalSize -le $InlineMaxBytes) {
    $contentBytes = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($PayloadPath))

    $payload = @{
        "@odata.type" = "#microsoft.graph.fileAttachment"
        name = $Name
        contentType = $ContentType
        contentBytes = $contentBytes
    }

    $null = Invoke-DraftGraphRequest -Method "POST" -Uri "/me/messages/$encodedId/attachments" -Body $payload
    $transferMode = "inline"
}
else {
    $sessionRequest = @{
        AttachmentItem = @{
            attachmentType = "file"
            name = $Name
            contentType = $ContentType
            size = $totalSize
        }
    }

    $session = Invoke-DraftGraphRequest `
        -Method "POST" `
        -Uri "/me/messages/$encodedId/attachments/createUploadSession" `
        -Body $sessionRequest

    $uploadUrl = [string]$session.uploadUrl
    if (-not (Test-DraftAttachmentUploadUrlAllowed -Url $uploadUrl)) {
        throw "Draft attachment upload session returned a URL outside the allowed Microsoft upload hosts."
    }

    $stream = [System.IO.File]::OpenRead($PayloadPath)
    try {
        $position = [long]0
        while ($position -lt $totalSize) {
            $count = [int][Math]::Min($ChunkBytes, $totalSize - $position)
            $buffer = New-Object byte[] $count

            $stream.Position = $position
            $filled = 0
            while ($filled -lt $count) {
                $read = $stream.Read($buffer, $filled, $count - $filled)
                if ($read -le 0) {
                    throw "Draft attachment staging file ended before the expected byte count."
                }
                $filled += $read
            }

            $response = Invoke-DraftAttachmentChunk `
                -UploadUrl $uploadUrl `
                -Bytes $buffer `
                -RangeStart $position `
                -TotalSize $totalSize

            $nextPosition = $position + $count

            # Graph answers a non-final chunk with the ranges it still wants.
            # Honoring that instead of assuming our own arithmetic is what makes
            # a partially-accepted chunk resume correctly rather than silently
            # writing a corrupt attachment.
            if ($response.StatusCode -eq 200 -and $response.Content) {
                try {
                    $state = $response.Content | ConvertFrom-Json
                    $ranges = @($state.nextExpectedRanges)
                    if ($ranges.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]$ranges[0])) {
                        $expected = [long](([string]$ranges[0]) -split "-")[0]
                        if ($expected -gt 0) {
                            $nextPosition = $expected
                        }
                    }
                }
                catch {
                    # A body we cannot parse is not fatal; sequential position stands.
                }
            }

            if ($nextPosition -le $position) {
                throw "Draft attachment upload session stopped making progress."
            }
            $position = $nextPosition
        }
    }
    finally {
        $stream.Dispose()
    }

    $transferMode = "upload_session"
}

$updated = Get-DraftMessageById -Id $Id
Assert-IsDraftMessage $updated

$attachmentsAfter = @(Get-DraftAttachments -Id $Id)
$added = $null
foreach ($attachment in $attachmentsAfter) {
    if (-not $idsBefore.ContainsKey([string]$attachment.Id)) {
        $added = $attachment
        break
    }
}
if ($null -eq $added) {
    throw "The draft reported no new attachment after the upload completed."
}

ConvertTo-JsonOutput @{
    Draft = ConvertTo-DraftMessageShape $updated
    Added = $added
    Attachments = @($attachmentsAfter)
    TransferMode = $transferMode
}
