param(
    [Parameter(Mandatory = $true)][string]$Id,
    [string]$Body = "",
    [switch]$ReplyAll
)

. "$PSScriptRoot/draft_graph_helpers.ps1"

Connect-OutlookDraftGraph

$encodedSourceId = Encode-GraphPathSegment $Id
$createBody = $null
if ($PSBoundParameters.ContainsKey("Body") -and -not [string]::IsNullOrWhiteSpace($Body)) {
    # Use createReply's comment parameter so Graph/Outlook preserves the
    # standard quoted original-message section below the reply text.
    $createBody = @{
        comment = $Body
    }
}

# createReplyAll has Outlook derive every original To/Cc recipient (minus the
# mailbox owner); createReply addresses the original sender only. Which one is
# right depends on the thread, and that judgement stays with the caller.
$action = if ($ReplyAll) { "createReplyAll" } else { "createReply" }
$created = Invoke-DraftGraphRequest -Method "POST" -Uri "/me/messages/$encodedSourceId/$action" -Body $createBody
$draft = Get-DraftMessageById -Id $created.id
Assert-IsDraftMessage $draft

ConvertTo-JsonOutput (ConvertTo-DraftMessageShape $draft)
