param(
    [Parameter(Mandatory = $true)]
    [string]$MessageId,

    [Parameter(Mandatory = $true)]
    [string]$AttachmentId,

    [int]$MaxBytes = 26214400
)

# Fetches one attachment's bytes and emits them as base64 JSON on stdout.
# This script performs zero filesystem writes by design: the Swift caller is
# the only place bytes touch disk, so the destination-path policy lives in
# testable Swift and this script stays provably write-incapable.

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$GraphBaseUri = "https://graph.microsoft.com/v1.0"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

$GraphRequestMaxAttempts = 4
$GraphRequestInitialDelaySeconds = 2

function Test-IsTransientGraphFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]

    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }

    if ($Failure.Exception) {
        $messages.Add([string]$Failure.Exception.Message)
        $exception = $Failure.Exception.InnerException
        while ($exception) {
            $messages.Add([string]$exception.Message)
            $exception = $exception.InnerException
        }
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    $transientMarkers = @(
        "timed out",
        "timeout",
        "request was aborted",
        "request aborted",
        "transport connection",
        "underlying connection was closed",
        "connection was closed",
        "connection closed",
        "temporarily unavailable",
        "service unavailable",
        "gateway timeout",
        "too many requests",
        "429",
        "502",
        "503",
        "504"
    )

    foreach ($marker in $transientMarkers) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }

    return $false
}

function Encode-GraphPathSegment {
    param([Parameter(Mandatory = $true)][string]$Value)

    [System.Uri]::EscapeDataString($Value)
}

# The only Graph shapes this script may touch: the single-attachment metadata
# GET (optionally with a $select projection) on /me/messages. Anything else,
# including absolute URLs and nextLinks, is rejected before any request runs.
function Test-AttachmentGraphRequestAllowed {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Uri
    )

    if ($Method -ne "GET") {
        return $false
    }
    if ($Uri -match "^/me/messages/[^/?]+/attachments/[^/?]+$") {
        return $true
    }
    if ($Uri -match "^/me/messages/[^/?]+/attachments/[^/?]+\?\`$select=[A-Za-z0-9,]+$") {
        return $true
    }
    return $false
}

function Resolve-AttachmentGraphUri {
    param([Parameter(Mandatory = $true)][string]$Uri)

    if ($Uri.StartsWith("/")) {
        return "$GraphBaseUri$Uri"
    }
    throw "Attachment download attempted a malformed Graph URI."
}

function Invoke-AttachmentGraphRequest {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("GET")]
        [string]$Method,

        [Parameter(Mandatory = $true)]
        [string]$Uri
    )

    if (-not (Test-AttachmentGraphRequestAllowed -Method $Method -Uri $Uri)) {
        throw "Attachment download attempted an endpoint outside the attachment-read allowlist."
    }

    $resolvedUri = Resolve-AttachmentGraphUri -Uri $Uri
    $attempt = 0
    $delaySeconds = $GraphRequestInitialDelaySeconds

    while ($true) {
        try {
            return Invoke-MgGraphRequest -Method $Method -Uri $resolvedUri -OutputType PSObject
        }
        catch {
            $attempt += 1
            if ($attempt -ge $GraphRequestMaxAttempts -or -not (Test-IsTransientGraphFailure $_)) {
                throw
            }

            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}

$encodedMessageId = Encode-GraphPathSegment $MessageId
$encodedAttachmentId = Encode-GraphPathSegment $AttachmentId
$basePath = "/me/messages/$encodedMessageId/attachments/$encodedAttachmentId"

# Two-phase fetch: a $select projection first so oversized files are rejected
# before their bytes ever cross the wire.
$metadata = Invoke-AttachmentGraphRequest -Method "GET" -Uri "$basePath`?`$select=id,name,contentType,size,isInline"
$odataType = [string]$metadata.'@odata.type'
$size = 0
if ($metadata.size) {
    $size = [long]$metadata.size
}

switch ($odataType) {
    "#microsoft.graph.referenceAttachment" {
        $detail = Invoke-AttachmentGraphRequest -Method "GET" -Uri $basePath
        [PSCustomObject]@{
            Kind = "reference"
            Id = [string]$metadata.id
            Name = [string]$metadata.name
            ContentType = [string]$metadata.contentType
            Size = $size
            SourceUrl = [string]$detail.sourceUrl
            ProviderType = [string]$detail.providerType
        } | ConvertTo-Json -Depth 4 -Compress
        exit 0
    }
    "#microsoft.graph.itemAttachment" {
        [PSCustomObject]@{
            Kind = "item"
            Id = [string]$metadata.id
            Name = [string]$metadata.name
            ContentType = [string]$metadata.contentType
            Size = $size
            Note = "Attached Outlook items (emails, contacts) are not downloadable as files in this phase."
        } | ConvertTo-Json -Depth 4 -Compress
        exit 0
    }
    default {
        if ($size -gt $MaxBytes) {
            Write-Error "Attachment is $size bytes, above the $MaxBytes byte limit."
            exit 1
        }

        $detail = Invoke-AttachmentGraphRequest -Method "GET" -Uri $basePath
        $contentBase64 = [string]$detail.contentBytes
        if ([string]::IsNullOrWhiteSpace($contentBase64)) {
            Write-Error "Attachment has no downloadable content bytes."
            exit 1
        }

        [PSCustomObject]@{
            Kind = "file"
            Id = [string]$metadata.id
            Name = [string]$metadata.name
            ContentType = [string]$metadata.contentType
            Size = $size
            IsInline = [bool]$metadata.isInline
            ContentBase64 = $contentBase64
        } | ConvertTo-Json -Depth 4 -Compress
        exit 0
    }
}
