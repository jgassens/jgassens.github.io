$ErrorActionPreference = "Stop"
$GraphBaseUri = "https://graph.microsoft.com/v1.0"

function Connect-OutlookDraftGraph {
    Connect-MgGraph -Scopes "User.Read","Mail.Read","Mail.ReadWrite" -NoWelcome | Out-Null
}

function ConvertTo-DraftRecipients {
    param([string]$Recipients)

    if ([string]::IsNullOrWhiteSpace($Recipients)) {
        return @()
    }

    $items = @()
    foreach ($raw in ($Recipients -split "[,;]")) {
        $address = $raw.Trim()
        if ($address.Length -eq 0) {
            continue
        }
        $items += @{
            emailAddress = @{
                address = $address
            }
        }
    }
    return @($items)
}

function ConvertFrom-DraftRecipients {
    param($Recipients)

    $items = @()
    if ($null -eq $Recipients) {
        return @()
    }

    foreach ($recipient in @($Recipients)) {
        if ($null -eq $recipient.emailAddress) {
            continue
        }
        $items += @{
            DisplayName = $recipient.emailAddress.name
            Address = $recipient.emailAddress.address
        }
    }
    return @($items)
}

function ConvertTo-DraftMessageShape {
    param($Message)

    @{
        Id = $Message.id
        Subject = $Message.subject
        To = @(ConvertFrom-DraftRecipients $Message.toRecipients)
        Cc = @(ConvertFrom-DraftRecipients $Message.ccRecipients)
        Bcc = @(ConvertFrom-DraftRecipients $Message.bccRecipients)
        BodyPreview = $Message.bodyPreview
        Body = if ($null -ne $Message.body) { $Message.body.content } else { $null }
        LastModifiedDateTime = $Message.lastModifiedDateTime
        IsDraft = [bool]$Message.isDraft
        HasAttachments = [bool]$Message.hasAttachments
        WebLink = $Message.webLink
    }
}

function ConvertTo-DraftAttachmentShape {
    param($Attachment)

    @{
        Id = [string]$Attachment.id
        Name = [string]$Attachment.name
        ContentType = [string]$Attachment.contentType
        Size = [int]$Attachment.size
        IsInline = [bool]$Attachment.isInline
    }
}

# Metadata only. Attachment content bytes are never read back through the draft
# lane; reading existing attachment bytes is the read lane's job
# (scripts/download_attachment.ps1, which holds read-only scopes).
function Get-DraftAttachments {
    param([Parameter(Mandatory = $true)][string]$Id)

    $encodedId = Encode-GraphPathSegment $Id
    $select = "id,name,contentType,size,isInline"
    $response = Invoke-DraftGraphRequest -Method "GET" -Uri "/me/messages/$encodedId/attachments?`$select=$select"

    $items = @()
    foreach ($attachment in @($response.value)) {
        $items += ConvertTo-DraftAttachmentShape $attachment
    }
    return @($items)
}

function ConvertTo-JsonOutput {
    param($Value)

    $Value | ConvertTo-Json -Depth 20 -Compress
}

function Encode-GraphPathSegment {
    param([Parameter(Mandatory = $true)][string]$Value)

    [System.Uri]::EscapeDataString($Value)
}

function Test-DraftGraphRequestAllowed {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $true)][string]$Uri
    )

    if ($Method -eq "POST" -and $Uri -eq "/me/messages") {
        return $true
    }
    if ($Method -eq "GET" -and ($Uri -eq "/me/mailFolders/Drafts/messages" -or $Uri.StartsWith("/me/mailFolders/Drafts/messages?"))) {
        return $true
    }
    if ($Method -eq "GET" -and $Uri.StartsWith("/me/messages/") -and $Uri.Contains("?`$select=")) {
        return $true
    }
    # Adding a file attachment to a draft. The collection POST is the only
    # attachment-shaped write the draft lane may make, and the caller has
    # already proved the target is a draft.
    if ($Method -eq "POST" -and $Uri -match '^/me/messages/[^/?]+/attachments$') {
        return $true
    }
    # Opening an upload session for a file too large for the single-request POST.
    # This only mints a pre-authenticated upload URL; the bytes themselves go
    # through Invoke-DraftAttachmentChunk, which has its own host allowlist.
    if ($Method -eq "POST" -and $Uri -match '^/me/messages/[^/?]+/attachments/createUploadSession$') {
        return $true
    }
    if ($Method -eq "PATCH" -and $Uri -match "^/me/messages/[^/]+$") {
        return $true
    }
    # Deleting one saved draft. Same URI shape as deleting real mail, so the
    # caller must have already proved isDraft on the target; this allowlist entry
    # cannot tell them apart and is not the fence.
    if ($Method -eq "DELETE" -and $Uri -match "^/me/messages/[^/]+$") {
        return $true
    }
    if ($Method -eq "POST" -and $Uri -match "^/me/messages/[^/]+/createReply$") {
        return $true
    }
    if ($Method -eq "POST" -and $Uri -match "^/me/messages/[^/]+/createForward$") {
        return $true
    }
    return $false
}

function Invoke-DraftGraphRequest {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("GET","POST","PATCH","DELETE")]
        [string]$Method,

        [Parameter(Mandatory = $true)]
        [string]$Uri,

        [object]$Body = $null
    )

    if (-not (Test-DraftGraphRequestAllowed -Method $Method -Uri $Uri)) {
        throw "Draft operation attempted an endpoint outside the saved-draft allowlist."
    }

    $resolvedUri = Resolve-DraftGraphUri -Uri $Uri
    $params = @{
        Method = $Method
        Uri = $resolvedUri
        OutputType = "PSObject"
    }
    if ($null -ne $Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 20)
        $params.ContentType = "application/json"
    }

    Invoke-MgGraphRequest @params
}

function Resolve-DraftGraphUri {
    param([Parameter(Mandatory = $true)][string]$Uri)

    if ($Uri.StartsWith("https://graph.microsoft.com/v1.0/")) {
        return $Uri
    }
    if ($Uri.StartsWith("/")) {
        return "$GraphBaseUri$Uri"
    }
    throw "Draft operation attempted a malformed Graph URI."
}

function Get-DraftMessageById {
    param([Parameter(Mandatory = $true)][string]$Id)

    $encodedId = Encode-GraphPathSegment $Id
    $select = "id,subject,toRecipients,ccRecipients,bccRecipients,bodyPreview,body,lastModifiedDateTime,isDraft,hasAttachments,webLink"
    Invoke-DraftGraphRequest -Method "GET" -Uri "/me/messages/$encodedId`?`$select=$select"
}

function Assert-IsDraftMessage {
    param($Message)

    if ($null -eq $Message -or $Message.isDraft -ne $true) {
        throw "Target message is not an Outlook saved draft."
    }
}

# ---------------------------------------------------------------------------
# Large-attachment upload sessions
# ---------------------------------------------------------------------------
#
# Graph answers createUploadSession with a pre-authenticated uploadUrl on an
# Outlook host, not on graph.microsoft.com, and the chunk PUTs must carry no
# Authorization header. That puts the chunk transport outside
# Invoke-DraftGraphRequest's URI allowlist, so it gets its own host allowlist
# instead: a response that named some other host would otherwise be able to
# redirect the user's file bytes off-tenant.

$DraftAttachmentUploadHostSuffixes = @(
    ".office.com",
    ".office365.com",
    ".office.net",
    ".outlook.com",
    ".microsoft.com"
)

function Test-DraftAttachmentUploadUrlAllowed {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Url)

    if ([string]::IsNullOrWhiteSpace($Url)) {
        return $false
    }

    $parsed = $null
    if (-not [System.Uri]::TryCreate($Url, [System.UriKind]::Absolute, [ref]$parsed)) {
        return $false
    }
    if ($parsed.Scheme -ne "https") {
        return $false
    }
    # Credentials embedded in the URL are never legitimate here and would be a
    # sign the value did not come from Graph.
    if (-not [string]::IsNullOrEmpty($parsed.UserInfo)) {
        return $false
    }

    # Not $host: that is a PowerShell automatic variable and assigning to it throws.
    $hostName = $parsed.Host.ToLowerInvariant()
    foreach ($suffix in $DraftAttachmentUploadHostSuffixes) {
        if ($hostName.EndsWith($suffix)) {
            return $true
        }
    }
    return $false
}

function Test-IsTransientUploadFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]
    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }
    $exception = $Failure.Exception
    while ($exception) {
        $messages.Add([string]$exception.Message)
        $exception = $exception.InnerException
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    foreach ($marker in @(
        "timed out", "timeout", "request was aborted", "request aborted",
        "transport connection", "connection was closed", "connection closed",
        "temporarily unavailable", "service unavailable", "gateway timeout",
        "too many requests", "429", "500", "502", "503", "504"
    )) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }
    return $false
}

# PUTs one byte range to the session's upload URL. No Authorization header by
# design: the URL is already pre-authenticated, and Graph rejects the request if
# one is attached. Redirects are refused outright rather than followed, so a
# 3xx can never carry the bytes to an unvetted host.
function Invoke-DraftAttachmentChunk {
    param(
        [Parameter(Mandatory = $true)][string]$UploadUrl,
        [Parameter(Mandatory = $true)][byte[]]$Bytes,
        [Parameter(Mandatory = $true)][long]$RangeStart,
        [Parameter(Mandatory = $true)][long]$TotalSize,
        [int]$MaxAttempts = 4
    )

    if (-not (Test-DraftAttachmentUploadUrlAllowed -Url $UploadUrl)) {
        throw "Draft attachment upload session returned a URL outside the allowed Microsoft upload hosts."
    }

    $rangeEnd = $RangeStart + $Bytes.Length - 1
    $headers = @{
        "Content-Range" = "bytes $RangeStart-$rangeEnd/$TotalSize"
    }

    $attempt = 0
    $delaySeconds = 2
    while ($true) {
        try {
            return Invoke-WebRequest `
                -Method "PUT" `
                -Uri $UploadUrl `
                -Headers $headers `
                -Body $Bytes `
                -ContentType "application/octet-stream" `
                -MaximumRedirection 0 `
                -SkipHeaderValidation
        }
        catch {
            $attempt += 1
            if ($attempt -ge $MaxAttempts -or -not (Test-IsTransientUploadFailure $_)) {
                throw
            }
            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}
