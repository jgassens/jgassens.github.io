param(
    [Parameter(Mandatory = $true)]
    [string]$MessageId,

    [int]$MaxTextBytes = 2000000,

    [int]$MaxExtractedChars = 8000
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$ctx = Get-MgContext

if (-not $ctx -or -not $ctx.Account) {
    try {
        Connect-MgGraph -Scopes "User.Read","Mail.Read" -NoWelcome | Out-Null
        $ctx = Get-MgContext
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if (-not $ctx -or -not $ctx.Account) {
    Write-Error "Not authenticated. Run Connect-MgGraph -Scopes 'User.Read','Mail.Read' first."
    exit 1
}

$GraphRequestMaxAttempts = 4
$GraphRequestInitialDelaySeconds = 2

function Test-IsTransientGraphFailure {
    param($Failure)

    $messages = New-Object System.Collections.Generic.List[string]

    if ($null -ne $Failure) {
        $messages.Add([string]$Failure)
    }

    if ($Failure -is [System.Management.Automation.ErrorRecord]) {
        if ($Failure.Exception) {
            $messages.Add([string]$Failure.Exception.Message)
            $exception = $Failure.Exception.InnerException
            while ($exception) {
                $messages.Add([string]$exception.Message)
                $exception = $exception.InnerException
            }
        }
    } elseif ($Failure.Exception) {
        $messages.Add([string]$Failure.Exception.Message)
        $exception = $Failure.Exception.InnerException
        while ($exception) {
            $messages.Add([string]$exception.Message)
            $exception = $exception.InnerException
        }
    }

    $combined = ($messages -join " ").ToLowerInvariant()
    $transientMarkers = @(
        "timed out",
        "timeout",
        "request was aborted",
        "request aborted",
        "transport connection",
        "underlying connection was closed",
        "connection was closed",
        "connection closed",
        "temporarily unavailable",
        "service unavailable",
        "gateway timeout",
        "too many requests",
        "429",
        "502",
        "503",
        "504"
    )

    foreach ($marker in $transientMarkers) {
        if ($combined.Contains($marker)) {
            return $true
        }
    }

    return $false
}

function Invoke-GraphRequestWithRetry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Uri
    )

    $attempt = 0
    $delaySeconds = $GraphRequestInitialDelaySeconds

    while ($true) {
        try {
            return Invoke-MgGraphRequest -Method GET -Uri $Uri -OutputType PSObject
        }
        catch {
            $attempt += 1
            if ($attempt -ge $GraphRequestMaxAttempts -or -not (Test-IsTransientGraphFailure $_)) {
                throw
            }

            Start-Sleep -Seconds $delaySeconds
            $delaySeconds = [Math]::Min($delaySeconds * 2, 15)
        }
    }
}

function Limit-Text {
    param(
        [AllowNull()]
        [string]$Text,
        [int]$MaxChars
    )

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $normalized = ([string]$Text) -replace "\s+", " "
    $normalized = $normalized.Trim()
    if ($normalized.Length -le $MaxChars) {
        return $normalized
    }
    return $normalized.Substring(0, $MaxChars)
}

function Get-StringFromBytes {
    param([byte[]]$Bytes)

    if (-not $Bytes -or $Bytes.Length -eq 0) {
        return ""
    }

    try {
        return [System.Text.Encoding]::UTF8.GetString($Bytes)
    }
    catch {
        try {
            return [System.Text.Encoding]::Default.GetString($Bytes)
        }
        catch {
            return ""
        }
    }
}

function Get-DocxTextFromBytes {
    param([byte[]]$Bytes)

    if (-not $Bytes -or $Bytes.Length -eq 0) {
        return ""
    }

    try {
        Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue | Out-Null
        $stream = [System.IO.MemoryStream]::new($Bytes)
        $archive = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Read)
        $parts = New-Object System.Collections.Generic.List[string]
        foreach ($entry in $archive.Entries) {
            if ($entry.FullName -notmatch "^word/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml$") {
                continue
            }
            $reader = [System.IO.StreamReader]::new($entry.Open())
            try {
                $xml = $reader.ReadToEnd()
            }
            finally {
                $reader.Dispose()
            }
            $text = $xml -replace "<w:tab\s*/>", " "
            $text = $text -replace "</w:p>", " "
            $text = $text -replace "<[^>]+>", " "
            $text = [System.Net.WebUtility]::HtmlDecode($text)
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                $parts.Add($text)
            }
        }
        return ($parts.ToArray() -join " ")
    }
    catch {
        return ""
    }
    finally {
        if ($archive) { $archive.Dispose() }
        if ($stream) { $stream.Dispose() }
    }
}

function Get-AttachmentTextPreview {
    param(
        [Parameter(Mandatory = $true)]
        $Attachment,
        [int]$MaxBytes,
        [int]$MaxChars
    )

    $name = ([string]$Attachment.name).ToLowerInvariant()
    $contentType = ([string]$Attachment.contentType).ToLowerInvariant()
    $size = 0
    if ($Attachment.size) {
        $size = [int]$Attachment.size
    }
    if ($size -le 0 -or $size -gt $MaxBytes) {
        return ""
    }

    $extractable =
        $contentType.StartsWith("text/") -or
        $contentType.Contains("json") -or
        $contentType.Contains("xml") -or
        $contentType.Contains("csv") -or
        $contentType.Contains("html") -or
        $contentType.Contains("rtf") -or
        $contentType.Contains("wordprocessingml.document") -or
        $contentType.Contains("application/msword") -or
        $name.EndsWith(".txt") -or
        $name.EndsWith(".md") -or
        $name.EndsWith(".csv") -or
        $name.EndsWith(".json") -or
        $name.EndsWith(".xml") -or
        $name.EndsWith(".html") -or
        $name.EndsWith(".htm") -or
        $name.EndsWith(".rtf") -or
        $name.EndsWith(".docx")

    if (-not $extractable) {
        return ""
    }

    try {
        $detailUrl = "https://graph.microsoft.com/v1.0/me/messages/$([uri]::EscapeDataString($MessageId))/attachments/$([uri]::EscapeDataString([string]$Attachment.id))"
        $detail = Invoke-GraphRequestWithRetry -Uri $detailUrl
        if ([string]::IsNullOrWhiteSpace([string]$detail.contentBytes)) {
            return ""
        }
        $bytes = [Convert]::FromBase64String([string]$detail.contentBytes)
        if ($contentType.Contains("wordprocessingml.document") -or $name.EndsWith(".docx")) {
            return Limit-Text -Text (Get-DocxTextFromBytes -Bytes $bytes) -MaxChars $MaxChars
        }

        $text = Get-StringFromBytes -Bytes $bytes
        if ($contentType.Contains("html") -or $name.EndsWith(".html") -or $name.EndsWith(".htm")) {
            $text = $text -replace "<[^>]+>", " "
            $text = [System.Net.WebUtility]::HtmlDecode($text)
        }
        if ($contentType.Contains("rtf") -or $name.EndsWith(".rtf")) {
            $text = $text -replace "\\'[0-9a-fA-F]{2}", " "
            $text = $text -replace "\\[a-zA-Z]+\d* ?", " "
            $text = $text -replace "[{}]", " "
        }
        return Limit-Text -Text $text -MaxChars $MaxChars
    }
    catch {
        return ""
    }
}

# Keep collection select to base microsoft.graph.attachment properties. Graph rejects
# fileAttachment-only fields such as contentId/contentLocation on the base collection.
$attachmentSelect = "id,name,contentType,size,isInline,lastModifiedDateTime"
$requestUrl = "https://graph.microsoft.com/v1.0/me/messages/$([uri]::EscapeDataString($MessageId))/attachments?`$select=$attachmentSelect&`$top=200"
$attachments = New-Object System.Collections.Generic.List[object]

while ($requestUrl) {
    $response = Invoke-GraphRequestWithRetry -Uri $requestUrl
    foreach ($attachment in @($response.value)) {
        $metadata = [ordered]@{}
        foreach ($property in @($attachment.PSObject.Properties)) {
            if ($property.Name -eq "contentBytes") {
                continue
            }
            $metadata[$property.Name] = $property.Value
        }
        $metadataJson = ""
        try {
            $metadataJson = ConvertTo-Json -InputObject $metadata -Depth 8 -Compress
        }
        catch {
            $metadataJson = ""
        }

        $attachments.Add([PSCustomObject]@{
            Id = [string]$attachment.id
            Name = [string]$attachment.name
            ContentType = [string]$attachment.contentType
            Size = [int]$attachment.size
            IsInline = [bool]$attachment.isInline
            ODataType = [string]$attachment.'@odata.type'
            LastModifiedDateTime = [string]$attachment.lastModifiedDateTime
            ContentId = [string]$attachment.contentId
            ContentLocation = [string]$attachment.contentLocation
            ExtractedText = Get-AttachmentTextPreview -Attachment $attachment -MaxBytes $MaxTextBytes -MaxChars $MaxExtractedChars
            MetadataJson = $metadataJson
        })
    }

    if ($response.'@odata.nextLink') {
        $requestUrl = [string]$response.'@odata.nextLink'
    } else {
        $requestUrl = $null
    }
}

ConvertTo-Json -InputObject @($attachments.ToArray()) -Depth 4
